<?php
$cfg['blowfish_secret'] = 'gV4U1fs3M5dkrqNcPQdW5WgI1zjkDVyL';
?>
