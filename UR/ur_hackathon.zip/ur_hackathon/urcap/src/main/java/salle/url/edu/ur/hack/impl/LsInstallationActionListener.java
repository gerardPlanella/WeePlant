package salle.url.edu.ur.hack.impl;

public class LsInstallationActionListener {
}
