//
//  ChatProtocol.swift
//  URApp
//
//  Created by Alumne on 28/03/2019.
//  Copyright © 2019 x.roma_gabriel.cammany. All rights reserved.
//

import UIKit

protocol ChatProtocol {
    func microphoneClick(_ sender: Any)
    func microphoneReleased(_ sender: Any)

}
