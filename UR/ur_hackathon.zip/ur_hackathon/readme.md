In development - UR Hackathon repository

Photos in [OneDrive folder](https://lasalleuniversities-my.sharepoint.com/:f:/g/personal/gabriel_cammany_students_salle_url_edu/EgvQ6ggHcMFLkosF0HqoTUsBhxasIVTj1-WI3FKcZQPpzw?e=lJNk4G) 

Here is the [link](https://github.com/thorsten-gehrig/alexa-remote-control) to the Alexa Control github repository.
